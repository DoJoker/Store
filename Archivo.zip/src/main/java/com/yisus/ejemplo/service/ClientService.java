package com.yisus.ejemplo.service;

import com.yisus.ejemplo.model.Client;

import java.util.List;

public interface ClientService {
    List<Client> getClients();
}
