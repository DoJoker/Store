package com.yisus.ejemplo.controller;

import com.yisus.ejemplo.service.ClientService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping("/api")
public class ProductController {

    private final ClientService clientService;

    /**
     * Its better manage the dependencies with this form (by contructor) and not using Autowired
     * @param clientService
     */
    @Autowired
    public ProductController(ClientService clientService) {
        this.clientService = clientService;
    }

    @GetMapping("/fibonnaci")
    ResponseEntity<String> getfibonnacciSeries() {
        log.info("fibonnacii, uri = /products");
        fibonnacii(10); //It cuoul be 10, 14, 29
        return new ResponseEntity<>("", HttpStatus.OK);
    }

    public void fibonnacii(Integer limit){
        int n1=0,n2=1,n3,i,count=limit;
        System.out.print(n1+" "+n2);
        for(i=2;i<count;++i)
        {
            n3=n1+n2;
            System.out.print(" "+n3);
            n1=n2;
            n2=n3;
        }
    }

    @GetMapping("/clients")
    ResponseEntity<String> getClients() {
        log.info("getClients, uri = /clients");
        clientService.getClients();
        log.info("clients obtained");
        /**
         * for the moment only returns all information about the client this should be included,
         * all accounts and all movements of this accounts XD.
         */

        return new ResponseEntity<>(HttpStatus.OK);
    }
}
