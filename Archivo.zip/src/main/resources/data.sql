DROP TABLE IF EXISTS billionaires;



CREATE TABLE IF NOT EXISTS client (
  client_id INT AUTO_INCREMENT  PRIMARY KEY,
  first_name VARCHAR(250) NOT NULL,
  last_name VARCHAR(250) NOT NULL
);

CREATE TABLE IF NOT EXISTS account(
  account_id INT AUTO_INCREMENT  PRIMARY KEY,
  account_number VARCHAR(250)  NOT NULL,
  balance double NOT NULL,
  client_id INT NOT NULL,
  foreign key (client_id) references client(client_id)
);

CREATE TABLE IF NOT EXISTS movements (
  movement_id INT AUTO_INCREMENT  PRIMARY KEY,
  name VARCHAR(250) NOT NULL
);

CREATE TABLE IF NOT EXISTS client_movements (
  cm_id INT AUTO_INCREMENT  PRIMARY KEY,
  account_id INT NOT NULL,
  movement_id INT NOT NULL,
  amount double NOT NULL,
  foreign key (account_id) references account(account_id),
  foreign key (movement_id) references movements(movement_id)
);

INSERT INTO client (first_name, last_name) VALUES
  ('Jesus', 'Lopez'),
  ('Santiago', 'Ramirez'),
  ('Andrea', 'Perez'),
  ('Gisele', 'Gomez'),
  ('Camila', 'Sanchez'),
  ('Sonia', 'Hernandez');

INSERT INTO movements (name) VALUES
    ('Retiro'),
    ('Abono');

INSERT INTO account (account_number, balance, client_id) VALUES
    ('1234567890',10000.50,1),
    ('1235345234',736457.34,1);


INSERT INTO client_movements (account_id, movement_id, amount) VALUES
  (1, 1, 50.2),
  (1, 1, 100);